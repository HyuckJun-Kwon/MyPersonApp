package com.person.controller;

public class Main {
	public static void main(String[] args) {
		new PersonController().run();
	}

}
